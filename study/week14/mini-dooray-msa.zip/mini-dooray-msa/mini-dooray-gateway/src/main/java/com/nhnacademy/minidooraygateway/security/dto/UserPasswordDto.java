package com.nhnacademy.minidooraygateway.security.dto;

import lombok.Data;

@Data
public class UserPasswordDto {
    private String password;
}

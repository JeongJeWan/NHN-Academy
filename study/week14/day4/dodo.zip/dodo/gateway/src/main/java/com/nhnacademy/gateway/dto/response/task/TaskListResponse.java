package com.nhnacademy.gateway.dto.response.task;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class TaskListResponse {

    private Long id;
    private String title;
}

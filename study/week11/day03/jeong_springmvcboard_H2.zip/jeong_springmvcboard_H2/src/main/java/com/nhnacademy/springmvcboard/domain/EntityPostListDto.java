package com.nhnacademy.springmvcboard.domain;

public interface EntityPostListDto {
    String getTitle();
    String getContent();
    String getWrtieTime();
    String getViewCount();
    String getUser();
}

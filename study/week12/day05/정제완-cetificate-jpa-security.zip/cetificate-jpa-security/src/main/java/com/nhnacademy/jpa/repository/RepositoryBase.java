package com.nhnacademy.jpa.repository;

public interface RepositoryBase {
}

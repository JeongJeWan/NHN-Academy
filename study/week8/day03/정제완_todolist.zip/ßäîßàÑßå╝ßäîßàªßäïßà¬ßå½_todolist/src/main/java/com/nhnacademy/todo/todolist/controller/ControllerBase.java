package com.nhnacademy.todo.todolist.controller;

public interface ControllerBase {
}

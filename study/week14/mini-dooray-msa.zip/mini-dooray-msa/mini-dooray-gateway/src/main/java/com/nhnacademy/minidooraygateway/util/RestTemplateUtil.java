package com.nhnacademy.minidooraygateway.util;


public class RestTemplateUtil {
    private RestTemplateUtil() {}


}

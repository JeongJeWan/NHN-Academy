package com.nhnacademy.student.exception;

public class IdExistException extends RuntimeException {
}

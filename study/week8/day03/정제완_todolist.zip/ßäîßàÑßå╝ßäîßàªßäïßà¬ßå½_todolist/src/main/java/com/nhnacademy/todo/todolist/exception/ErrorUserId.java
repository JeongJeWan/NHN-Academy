package com.nhnacademy.todo.todolist.exception;

public class ErrorUserId extends RuntimeException{
    public ErrorUserId() {super();}
}

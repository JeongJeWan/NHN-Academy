package com.nhnacademy.security.repository;

public interface RepositoryBase {
}

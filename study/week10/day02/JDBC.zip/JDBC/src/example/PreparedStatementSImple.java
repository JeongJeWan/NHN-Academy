package example;
import java.sql.*;

public class PreparedStatementSImple {
    private static final String driverName = "com.mysql.cj.jdbc.Driver";
    private static final String databaseURL = "jdbc:mysql://localhost/module06";
    public static void loadDriver(String driverName) {
        try {
            Class.forName(driverName);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        loadDriver(driverName);

        Connection myConnection = null;
        PreparedStatement statement = null;
        ResultSet result = null;

        try {
            myConnection = DriverManager.getConnection(databaseURL, "root", "258011");
            String sqlQuery = "SELECT PassengerName, Grade, Age FROM Passenger";
            statement = myConnection.prepareStatement(sqlQuery);
            // statement.setInt(1, 2);

            result = statement.executeQuery();

            for(;result.next();) {
                System.out.print(result.getString(1) + " ");
                System.out.print(result.getString(2) + " ");
                System.out.println(result.getString(3));
            }

            result.close();
            statement.close();
            myConnection.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}

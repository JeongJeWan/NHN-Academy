package com.nhnacademy.todo.mapper;

import com.nhnacademy.todo.config.RootConfig;
import com.nhnacademy.todo.domain.Event;
import com.nhnacademy.todo.dto.DailyRegisterCountResponseDto;
import com.nhnacademy.todo.dto.EventDto;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@WebAppConfiguration
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = RootConfig.class)
@Transactional
@Slf4j
public class EventMapperTest {

    @Autowired
    EventMapper eventMapper;

    @Test
    @Rollback(value = false)
    @DisplayName("event 저장")
    void save() {
        Event event = new Event("marco", "spring mvc", LocalDate.now());
        eventMapper.save(event);

        Assertions.assertThat(event.getId()).isNotZero();

    }

    @Test
    @Rollback(value = false)
    @DisplayName("event 수정")
    void update() {
        Event dummyEvent = new Event("marco", "spring mvc", LocalDate.now());
        dummyEvent.setId(5);

        eventMapper.update(dummyEvent);

        Event event = eventMapper.getEvent(9);
        log.info("event:{}", event);

        Assertions.assertThat(event.getSubject()).isEqualTo(dummyEvent.getSubject());
        Assertions.assertThat(event.getEventAt()).isEqualTo(dummyEvent.getEventAt());
    }

    @Test
    @Rollback(value = false)
    @DisplayName("event 조회")
    void getEvent() {
        Event event = eventMapper.getEvent(1);

        Assertions.assertThat(event.getSubject()).isEqualTo("Spring framework 학습");
        Assertions.assertThat(event.getEventAt()).isEqualTo("2023-05-06");
    }

    @Test
    @Rollback(value = false)
    @DisplayName("event is null")
    void getEvent_notFount() {
        Event event = eventMapper.getEvent(4);

        Assertions.assertThat(event).isNull();;
    }

    @Test
    @Rollback(value = false)
    @DisplayName("event 삭제")
    void deleteOne() {
        eventMapper.deleteOne(12);

        Event event = eventMapper.getEvent(12);
        Assertions.assertThat(event).isNull();
    }

    @Test
    @Rollback(value = false)
    @DisplayName("event 월별 조회")
    void getEventListByMonth() {

        List<EventDto> eventDtos = eventMapper.getEventListByMonthly(LocalDate.now().getYear(), LocalDate.now().getMonthValue());

        Assertions.assertThat(eventDtos).hasSize(eventDtos.size());
        Assertions.assertThat(eventDtos.get(0).getSubject()).isEqualTo("Spring framework 학습");
        Assertions.assertThat(eventDtos.get(1).getSubject()).isEqualTo("Spring framework 학습2");
        Assertions.assertThat(eventDtos.get(2).getSubject()).isEqualTo("Spring framework 학습3");
    }

    @Test
    @Rollback(value = false)
    @DisplayName("event 일별 조회")
    void getEventListByDaily() {
//        eventMapper.save(eventList.get(0));
//        eventMapper.save(eventList.get(1));
//        eventMapper.save(eventList.get(2));

        List<EventDto> eventDtos = eventMapper.getEventListByDaily(2023, 5, 6);

        Assertions.assertThat(eventDtos).hasSize(3);
        Assertions.assertThat(eventDtos.get(0).getSubject()).isEqualTo("Spring framework 학습");
        Assertions.assertThat(eventDtos.get(1).getSubject()).isEqualTo("Spring framework 학습2");
        Assertions.assertThat(eventDtos.get(2).getSubject()).isEqualTo("Spring framework 학습3");
    }

    @Test
    @Rollback(value = false)
    @DisplayName("event 일-등록 카운트")
    void getDayliyRegisterCount() {
        DailyRegisterCountResponseDto dailyRegisterCountResponseDto = eventMapper.getDailyRegisterCount(LocalDate.now());

        Assertions.assertThat(dailyRegisterCountResponseDto.getCount()).isEqualTo(1);
    }

    @Test
    @Rollback(value = false)
    @DisplayName("event 일 단위 삭제")
    void deleteEventByDaily() {
        eventMapper.deleteEventByDaily(LocalDate.now());

        Event event1 = eventMapper.getEvent(4);
        Event event2 = eventMapper.getEvent(5);
        Event event3 = eventMapper.getEvent(6);

        Assertions.assertThat(event1).isNull();
        Assertions.assertThat(event2).isNull();
        Assertions.assertThat(event3).isNull();
    }
}
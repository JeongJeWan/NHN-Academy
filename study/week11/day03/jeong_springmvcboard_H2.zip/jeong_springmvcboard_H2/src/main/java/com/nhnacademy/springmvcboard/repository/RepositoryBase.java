package com.nhnacademy.springmvcboard.repository;

// marker interface
public interface RepositoryBase{
}

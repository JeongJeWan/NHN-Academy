package com.nhnacademy.todo;

public interface Base {
}

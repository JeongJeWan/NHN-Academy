package com.nhnacademy.minidoorayuserapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniDoorayUserApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiniDoorayUserApiApplication.class, args);
	}

}

package com.nhnacademy.security.controller;

public interface ControllerBase {
}

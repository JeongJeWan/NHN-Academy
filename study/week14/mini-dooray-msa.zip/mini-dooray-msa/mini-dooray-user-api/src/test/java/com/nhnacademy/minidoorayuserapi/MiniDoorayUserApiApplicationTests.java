package com.nhnacademy.minidoorayuserapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniDoorayUserApiApplicationTests {

	@Test
	void contextLoads() {
	}

}

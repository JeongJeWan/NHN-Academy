package com.nhnacademy.todo.todolist.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class EventCreateResponseDto {
    private final long id;
}
package com.nhnacademy.minidooraygateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniDoorayGatewayApplicationTests {

    @Test
    void contextLoads() {
    }

}

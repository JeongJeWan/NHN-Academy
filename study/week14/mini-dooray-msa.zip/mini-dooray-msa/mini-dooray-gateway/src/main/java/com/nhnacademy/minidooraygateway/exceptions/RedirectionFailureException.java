package com.nhnacademy.minidooraygateway.exceptions;

public class RedirectionFailureException extends RuntimeException {
    public RedirectionFailureException(String msg) {
        super(msg);
    }
}

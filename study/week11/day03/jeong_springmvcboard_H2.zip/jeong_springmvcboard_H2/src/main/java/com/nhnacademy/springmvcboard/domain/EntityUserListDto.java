package com.nhnacademy.springmvcboard.domain;

public interface EntityUserListDto {
    String getUserId();
    String getUserName();
    String getProfileFileName();
    String getWriteTime();
}

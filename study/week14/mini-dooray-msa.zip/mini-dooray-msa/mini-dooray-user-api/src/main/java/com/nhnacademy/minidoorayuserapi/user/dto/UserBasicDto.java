package com.nhnacademy.minidoorayuserapi.user.dto;

import lombok.Data;

@Data
public class UserBasicDto {
    private Long userNo;

    private String id;

    private String email;
}

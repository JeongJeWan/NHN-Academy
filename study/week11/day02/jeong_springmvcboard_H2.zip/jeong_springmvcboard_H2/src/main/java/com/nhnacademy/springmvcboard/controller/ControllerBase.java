package com.nhnacademy.springmvcboard.controller;

public interface ControllerBase {
}

package com.nhnacademy.minidoorayprojectmanagementapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniDoorayProjectManagementApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiniDoorayProjectManagementApiApplication.class, args);
	}

}

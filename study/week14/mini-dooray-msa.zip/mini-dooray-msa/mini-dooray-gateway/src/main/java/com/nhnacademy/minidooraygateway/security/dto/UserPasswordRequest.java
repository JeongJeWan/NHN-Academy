package com.nhnacademy.minidooraygateway.security.dto;

import lombok.Data;

@Data
public class UserPasswordRequest {
    private String userId;
}

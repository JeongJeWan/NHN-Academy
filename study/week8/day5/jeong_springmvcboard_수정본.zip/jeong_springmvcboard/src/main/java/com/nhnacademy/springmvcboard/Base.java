package com.nhnacademy.springmvcboard;

public interface Base {
}

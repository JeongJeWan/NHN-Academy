package com.nhnacademy.security.dto;

import lombok.Data;

@Data
public class MemberId {
    private String id;
}

package com.nhnacademy.student;

// marker interface
public interface Base {
}

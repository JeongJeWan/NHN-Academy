package com.nhnacademy.springmvcboard.domain;

public interface EntityPostDto {
    String getTitle();
    String getContent();
}

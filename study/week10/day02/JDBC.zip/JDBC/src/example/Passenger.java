package example;
public class Passenger {
    int passengerNo;
    String name;
    int grade;
    int age;

    public Passenger(int passengerNo, String name, int grade, int age) {
        this.passengerNo = passengerNo;
        this.name = name;
        this.grade = grade;
        this.age = age;
    }

    public int getPassengerNo() {
        return this.passengerNo;
    }

    public String getName() {
        return this.name;
    }

    public int getGrade() {
        return this.grade;
    }

    public int getAge() {
        return this.age;
    }

    @Override
    public String toString() {
        return this.passengerNo + " " + this.name + " " + this.grade + " " + this.age;
    }
}

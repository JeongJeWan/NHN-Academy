package com.nhnacademy.jpa;

public interface Base {
}

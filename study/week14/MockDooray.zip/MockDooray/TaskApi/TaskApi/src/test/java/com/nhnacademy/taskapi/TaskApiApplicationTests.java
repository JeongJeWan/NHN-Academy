package com.nhnacademy.taskapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;




@SpringBootTest
class TaskApiApplicationTests {
    @Test
    void contextLoads() {
    }
}

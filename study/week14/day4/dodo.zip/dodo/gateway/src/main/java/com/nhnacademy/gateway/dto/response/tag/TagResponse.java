package com.nhnacademy.gateway.dto.response.tag;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class TagResponse {

    private Long id;
    private String name;
}

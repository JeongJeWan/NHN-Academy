package com.nhnacademy.gateway.exception;

public class WrongEmailException extends Throwable {
}

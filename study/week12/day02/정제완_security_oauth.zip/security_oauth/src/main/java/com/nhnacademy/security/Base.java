package com.nhnacademy.security;

public interface Base {
}

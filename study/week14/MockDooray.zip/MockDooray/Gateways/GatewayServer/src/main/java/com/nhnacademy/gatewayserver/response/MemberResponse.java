package com.nhnacademy.gatewayserver.response;

import lombok.*;


@Data

public class MemberResponse {
}

package com.nhnacademy.todo.mapper;

import com.nhnacademy.todo.domain.Event;
import com.nhnacademy.todo.dto.DailyRegisterCountResponseDto;
import com.nhnacademy.todo.dto.EventDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDate;
import java.util.List;

@Mapper
public interface EventMapper {
    // 등록
    void save(Event event);

    // 수정
    void update(Event event);

    // 조회
    Event getEvent(long eventId);

    // 삭제
    void deleteOne(long eventId);

    // daily 삭제
    void deleteEventByDaily(LocalDate eventAt);

    // 일 단위 등록 카운트
    DailyRegisterCountResponseDto getDailyRegisterCount(LocalDate targetDate);

    // 월단위 조회
    List<EventDto> getEventListByMonthly(@Param("year") Integer year, @Param("month") Integer month);

    // 일단위 조회
    List<EventDto> getEventListByDaily(@Param("year") Integer year, @Param("month") Integer month, @Param("day") Integer day);
}
package com.nhnacademy.jpa.dto.familyRelationship;

import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class RelationshipUpdateRequest {
    private String relationship;
}

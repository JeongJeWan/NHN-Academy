package com.nhnacademy.todo.todolist;

public interface Base {
}

package com.nhnacademy.todo.todolist.intercepter;

public class UnauthorizedInterceptor {
}

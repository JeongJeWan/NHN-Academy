package com.nhnacademy.springmvcboard.domain;

import com.nhnacademy.springmvcboard.entity.EntityPost;

import java.util.List;

public interface EntityUserDto {
    String getUserId();
    String getUserName();
    String getProfileFileName();
}

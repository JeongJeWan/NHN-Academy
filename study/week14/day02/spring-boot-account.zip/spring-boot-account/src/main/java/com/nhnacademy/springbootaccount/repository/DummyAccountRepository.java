package com.nhnacademy.springbootaccount.repository;

import com.nhnacademy.springbootaccount.entity.Account;
import org.springframework.stereotype.Repository;

import java.util.List;

//@Repository
//public class DummyAccountRepository implements AccountRepository{
//    @Override
//    public List<Account> findAll() {
//        return List.of(new Account("1", 100), new Account("2", 300), new Account("3", 400));
//    }
//}

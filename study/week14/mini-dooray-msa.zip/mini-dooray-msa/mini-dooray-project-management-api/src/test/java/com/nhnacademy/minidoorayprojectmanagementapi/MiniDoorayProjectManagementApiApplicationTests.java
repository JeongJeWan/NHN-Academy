package com.nhnacademy.minidoorayprojectmanagementapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniDoorayProjectManagementApiApplicationTests {

	@Test
	void contextLoads() {
	}

}

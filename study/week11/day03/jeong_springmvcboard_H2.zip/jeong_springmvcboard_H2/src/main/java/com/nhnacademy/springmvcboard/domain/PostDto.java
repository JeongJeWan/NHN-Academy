package com.nhnacademy.springmvcboard.domain;

public interface PostDto {
    String getTitle();
    String getContent();
    String getWrtieTime();
    String getViewCount();
}

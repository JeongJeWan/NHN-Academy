package com.nhnacademy.minidoorayprojectmanagementapi.comment.dto;

import lombok.Data;

@Data
public class CommentModifyRequest {
    private String content;
}

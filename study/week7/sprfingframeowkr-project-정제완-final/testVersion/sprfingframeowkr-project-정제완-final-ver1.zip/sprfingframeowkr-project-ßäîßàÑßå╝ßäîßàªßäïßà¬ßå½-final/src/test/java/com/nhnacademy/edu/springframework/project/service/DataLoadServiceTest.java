package com.nhnacademy.edu.springframework.project.service;

import com.nhnacademy.edu.springframework.project.config.StudentScoreServiceConfig;
import com.nhnacademy.edu.springframework.project.repository.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class DataLoadServiceTest {

    private CsvDataLoadService dataLoadService;
    private Students students;


    @BeforeEach
    void setUp() {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(StudentScoreServiceConfig.class);
        dataLoadService = context.getBean("csvDataLoadService", CsvDataLoadService.class);
        students = context.getBean("csvStudents", CsvStudents.class);
    }

    @Test
    void loadAndMerge() {
        dataLoadService.loadAndMerge();

        List<Student> studentList = (List<Student>) students.findAll();

        assertEquals(30, studentList.get(0).getScore().getScore());
        assertEquals(80, studentList.get(1).getScore().getScore());
        assertEquals(70, studentList.get(2).getScore().getScore());
        assertNull(studentList.get(3).getScore());
    }
}
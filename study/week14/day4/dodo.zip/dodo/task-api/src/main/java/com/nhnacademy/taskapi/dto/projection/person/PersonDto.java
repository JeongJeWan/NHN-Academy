package com.nhnacademy.taskapi.dto.projection.person;

public interface PersonDto {

    Long getMemberId();

    Long getTaskId();

    String getUsername();
}

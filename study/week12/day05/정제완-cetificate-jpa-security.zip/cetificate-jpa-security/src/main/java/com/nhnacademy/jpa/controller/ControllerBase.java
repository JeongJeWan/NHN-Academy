package com.nhnacademy.jpa.controller;

public interface ControllerBase {
}

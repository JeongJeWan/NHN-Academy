package com.nhnacademy.student.exception;

public class StudentNotFoundException extends RuntimeException{
}
